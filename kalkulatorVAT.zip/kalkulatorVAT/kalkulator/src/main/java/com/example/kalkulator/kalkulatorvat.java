package com.example.kalkulator;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class kalkulatorvat extends Application {

    @Override
    public void start(Stage primaryStage) {
        ToggleGroup metoda = new ToggleGroup();
        RadioButton nettodobrutto = new RadioButton("Od netto do brutto");
        nettodobrutto.setToggleGroup(metoda);
        nettodobrutto.setSelected(true);

        RadioButton bruttodonetto = new RadioButton("Od brutto do netto");
        bruttodonetto.setToggleGroup(metoda);

        RadioButton adjustToVAT = new RadioButton("Dopasuj do kwoty VAT");
        adjustToVAT.setToggleGroup(metoda);

        TextField poczatkowawartosc = new TextField();
        poczatkowawartosc.setPromptText("Wprowadź wartość");

        ComboBox<String> wyborstawki = new ComboBox<>();
        wyborstawki.getItems().addAll("23%", "8%", "5%", "0%");
        wyborstawki.setValue("23%");

        Label wyniknetto = new Label("Netto: ");
        Label wynikvat = new Label("VAT: ");
        Label wynikbrutto = new Label("Brutto: ");

        Button oblicz = new Button("OBLICZ");
        Button zamknij = new Button("Zamknij");
        
        VBox methodBox = new VBox(10, nettodobrutto, bruttodonetto, adjustToVAT);
        methodBox.setPadding(new Insets(10));

        GridPane dataPane = new GridPane();
        dataPane.setHgap(10);
        dataPane.setVgap(10);
        dataPane.setPadding(new Insets(10));
        dataPane.add(new Label("Wartość bazowa:"), 0, 0);
        dataPane.add(poczatkowawartosc, 1, 0);
        dataPane.add(new Label("Stawka VAT:"), 0, 1);
        dataPane.add(wyborstawki, 1, 1);

        VBox resultsBox = new VBox(10, wyniknetto, wynikvat, wynikbrutto);
        resultsBox.setPadding(new Insets(10));

        HBox buttonBox = new HBox(230, oblicz, zamknij);
        buttonBox.setAlignment(Pos.CENTER);

        VBox mainBox = new VBox(10, methodBox, dataPane,buttonBox, resultsBox);

        
        oblicz.setOnAction(e -> {
            try {
                double baseValue = Double.parseDouble(poczatkowawartosc.getText().replace(",", "."));
                double vatRate = Double.parseDouble(wyborstawki.getValue().replace("%", "")) / 100;

                double netto, vat, brutto;

                if (nettodobrutto.isSelected()) {
                    netto = baseValue;
                    vat = netto * vatRate;
                    brutto = netto + vat;
                } else if (bruttodonetto.isSelected()) {
                    brutto = baseValue;
                    netto = brutto / (1 + vatRate);
                    vat = brutto - netto;
                } else {
                    vat = baseValue;
                    netto = vat / vatRate;
                    brutto = netto + vat;
                }

                wyniknetto.setText(String.format("Netto: %.2f", netto));
                wynikvat.setText(String.format("VAT: %.2f @ %.0f%%", vat, vatRate * 100));
                wynikbrutto.setText(String.format("Brutto: %.2f", brutto));
            } catch (NumberFormatException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Proszę wprowadzić poprawną wartość liczbową.");
                alert.showAndWait();
            }
        });

        zamknij.setOnAction(e -> primaryStage.close());

       
        Scene scene = new Scene(mainBox, 400, 400);
        primaryStage.setTitle("Kalkulator VAT netto-brutto");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}